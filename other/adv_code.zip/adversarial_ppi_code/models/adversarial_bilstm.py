from theano import tensor as T
import theano.sandbox.cuda
from theano.ifelse import ifelse
from sklearn import cross_validation
from sklearn.utils import shuffle
import theano
from theano import config
import numpy as np
from theano.tensor.nnet.conv import conv2d
from theano.tensor.signal.pool import pool_2d as max_pool_2d
from theano.tensor.shared_randomstreams import RandomStreams
#srng2 = RandomStreams(seed=234)

from utils import *

class BiLSTM(object):

    def __init__(self, emb, pos, nh=256,
            nc=2, de=100, p_drop=0.5, use_feature_matching=False, supervised_gen=False,
            atth=128):
        '''
            emb :: Embedding Matrix
            nh :: hidden layer size
            nc :: Number of classes
            de :: Dimensionality of word embeddings
            p_drop :: Dropout probability
        '''
        self.supervised_gen = supervised_gen
        def recurrence(xi, mask, h_tm1, c_tm1, W_i, U_i, b_i, W_c, U_c, b_c, W_f, U_f, b_f, W_o2, U_o, b_o2, mask_in, mask_rec):
            x = xi*T.neq(mask, 0).dimshuffle(0,'x')
            x = dropout_scan(x, mask_in, dropout_switch, 0.2)

            x_i = T.dot(x, W_i) + b_i
            x_i = x_i*T.neq(mask, 0).dimshuffle(0,'x')

            x_f = T.dot(x, W_f) + b_f
            x_f = x_f*T.neq(mask, 0).dimshuffle(0,'x')

            x_c = T.dot(x, W_c) + b_c
            x_c = x_c*T.neq(mask, 0).dimshuffle(0,'x')

            x_o = T.dot(x, W_o2) + b_o2
            x_o = x_o*T.neq(mask, 0).dimshuffle(0,'x')

            h_tm1 = h_tm1*T.neq(mask, 0).dimshuffle(0,'x')
            h_tm1 = dropout_scan(h_tm1, mask_rec, dropout_switch, 0.2)

            i = hard_sigmoid(x_i + T.dot(h_tm1, U_i))
            f = hard_sigmoid(x_f + T.dot(h_tm1, U_f))
            c = f * c_tm1 + i * T.tanh(x_c + T.dot(h_tm1, U_c))
            o = hard_sigmoid(x_o + T.dot(h_tm1, U_o))
            h = o * T.tanh(c)
            return [h, c]

        # set values
        self.nh = nh
        # Source Embeddings
        self.emb = theano.shared(name='Words',
            value=emb.astype('float32'))
        self.target_emb = theano.shared(name='Words',
            value=emb.astype('float32'))
        self.avg_emb = theano.shared(name='Wordsa',
            value=emb.astype('float32'))

        self.pos = theano.shared(name='Pos',
            value=pos.astype('float32'))
        self.target_pos = theano.shared(name='Post',
            value=pos.astype('float32'))
        self.avg_pos = theano.shared(name='Posta',
            value=pos.astype('float32'))
        # Targt Embeddings

        # Source Output Weights
        self.attention_w = theano.shared(name='w_o',
                value=he_normal((nh+nh,1))
                .astype('float32'))
        self.attention_b = theano.shared(name='b_o',
            value=np.zeros((1,)).astype('float32'))

        self.w_o = theano.shared(name='w_o',
                value=he_normal((nh+nh,1))
                .astype('float32'))
        self.b_o = theano.shared(name='b_o',
            value=np.zeros((1,)).astype('float32'))

        self.w_o2 = theano.shared(name='w_o',
                value=he_normal((nh+nh,1))
                .astype('float32'))
        self.b_o2 = theano.shared(name='b_o',
            value=np.zeros((1,)).astype('float32'))

        # Discriminator Weights
        self.w_h_1 = theano.shared(name='w_h_1',
                value=he_normal((nh+nh, atth))
                .astype('float32'))
        self.b_h_1 = theano.shared(name='b_h_1',
            value=np.zeros((atth,)).astype('float32'))
        self.w_h_2 = theano.shared(name='w_h_2',
                value=he_normal((atth,atth))
                .astype('float32'))
        self.b_h_2 = theano.shared(name='b_h_2',
            value=np.zeros((atth,)).astype('float32'))
        self.w_h_3 = theano.shared(name='w_h_3',
                value=he_normal((atth,atth))
                .astype('float32'))
        self.b_h_3 = theano.shared(name='b_h_3',
            value=np.zeros((atth,)).astype('float32'))
        self.w_adv = theano.shared(name='w_adv',
                value=he_normal((atth,1))
                .astype('float32'))
        self.b_adv = theano.shared(name='b_adv',
            value=np.zeros((1,)).astype('float32'))

        # Update these parameters
        self.params_source = [self.w_o, self.b_o, self.emb, self.pos]
        self.params_source2 = [self.w_o2, self.b_o2, self.emb, self.pos]

        if self.supervised_gen:
            self.params_target = [self.target_emb, self.target_pos]
            source_target_idxs = T.matrix()
            source_target_e1_pos_idxs = T.matrix()
            source_target_e2_pos_idxs = T.matrix()
            source_target_x_e1_pos = self.target_pos[T.cast(source_target_e1_pos_idxs, 'int32')]
            source_target_x_e2_pos = self.target_pos[T.cast(source_target_e2_pos_idxs, 'int32')]
            source_target_x_word = self.target_emb[T.cast(source_target_idxs, 'int32')]
            source_target_x_word = T.concatenate([source_target_x_word, source_target_x_e1_pos,
                source_target_x_e2_pos], axis=2)
            mask = T.neq(source_target_idxs, 0)*1
            source_target_x_word = source_target_x_word*mask.dimshuffle(0, 1, 'x')
        else:
            self.params_target = [self.target_emb, self.target_pos]
            #self.params_target = [self.emb_target]

        #self.params_discriminator = [self.w_h_1, self.b_h_1, self.w_h_3, self.b_h_3,
        self.params_discriminator = [self.w_h_1, self.b_h_1,
            self.w_h_2, self.b_h_2, self.w_adv, self.b_adv]

        source_idxs = T.matrix()
        target_idxs = T.matrix()
        source_e1_pos_idxs = T.matrix()
        source_e2_pos_idxs = T.matrix()
        target_e1_pos_idxs = T.matrix()
        target_e2_pos_idxs = T.matrix()
        source_Y = T.ivector()

        # get word embeddings based on indicies
        source_x_word = self.emb[T.cast(source_idxs, 'int32')]
        source_x_e1_pos = self.pos[T.cast(source_e1_pos_idxs, 'int32')]
        source_x_e2_pos = self.pos[T.cast(source_e2_pos_idxs, 'int32')]
        source_x_word = T.concatenate([source_x_word, source_x_e1_pos,
            source_x_e2_pos], axis=2)
        #mask = T.neq(source_idxs, 0)*1
        #source_x_word = source_x_word*mask.dimshuffle(0, 1, 'x')

        target_x_word = self.target_emb[T.cast(target_idxs, 'int32')]
        target_x_e1_pos = self.target_pos[T.cast(target_e1_pos_idxs, 'int32')]
        target_x_e2_pos = self.target_pos[T.cast(target_e2_pos_idxs, 'int32')]
        target_x_word = T.concatenate([target_x_word, target_x_e1_pos,
            target_x_e2_pos], axis=2)
        #mask2 = T.neq(target_idxs, 0)*1
        #target_x_word = target_x_word*mask2.dimshuffle(0, 1, 'x')

        de = de + 2*pos.shape[1]

        source_fwd_params, source_bck_params = bilstm_weights(de, nh)
        target_fwd_params, target_bck_params = bilstm_weights(de, nh)
        avg_fwd_params, avg_bck_params= bilstm_weights(de, nh)

        self.params_source += source_fwd_params + source_bck_params
        self.params_source2 += source_fwd_params + source_bck_params
        self.params_target += target_fwd_params + target_bck_params
        self.params_avg = avg_fwd_params + avg_bck_params

        self.h0 = theano.shared(name='h0',
                                value=np.zeros((nh,), 
                                dtype="float32"))

        dropout_switch = T.scalar()
        real_attention = T.scalar()

        maskd1 = srng.binomial((source_x_word.shape[0], source_x_word.shape[-1]), p=0.8, dtype='float32')
        maskd2 = srng.binomial((source_x_word.shape[0],nh), p=0.8, dtype='float32')
        [source_h_fwd, cm], u = theano.scan(fn=recurrence,
                                sequences=[source_x_word.dimshuffle(1,0,2), source_idxs.dimshuffle(1,0)],
                                non_sequences=source_fwd_params+[maskd1, maskd2],
                                outputs_info=[T.alloc(self.h0, source_x_word.shape[0],nh), T.alloc(self.h0, source_x_word.shape[0],nh)],
                                n_steps=source_x_word.shape[1],
                                strict=True)

        maskd3 = srng.binomial((source_x_word.shape[0],source_x_word.shape[-1]), p=0.8, dtype='float32')
        maskd4 = srng.binomial((source_x_word.shape[0],nh), p=0.8, dtype='float32')
        [source_h_bck, c], u = theano.scan(fn=recurrence,
                                sequences=[source_x_word.dimshuffle(1,0,2)[::-1,:,:], source_idxs.dimshuffle(1,0)[::-1,:]],
                                non_sequences=source_bck_params+[maskd3, maskd4],
                                outputs_info=[T.alloc(self.h0, source_x_word.shape[0],nh), T.alloc(self.h0, source_x_word.shape[0],nh)],
                                n_steps=source_x_word.shape[1],
                                strict=True)

        maskd5 = srng.binomial((target_x_word.shape[0],target_x_word.shape[-1]), p=0.8, dtype='float32')
        maskd6 = srng.binomial((target_x_word.shape[0],nh), p=0.8, dtype='float32')
        [target_h_fwd, cm], u = theano.scan(fn=recurrence,
                                sequences=[target_x_word.dimshuffle(1,0,2), target_idxs.dimshuffle(1,0)],
                                non_sequences=target_fwd_params+[maskd5, maskd6],
                                outputs_info=[T.alloc(self.h0, target_x_word.shape[0],nh), T.alloc(self.h0, target_x_word.shape[0],nh)],
                                n_steps=target_x_word.shape[1],
                                strict=True)

        maskd7 = srng.binomial((target_x_word.shape[0],target_x_word.shape[-1]), p=0.8, dtype='float32')
        maskd8 = srng.binomial((target_x_word.shape[0],nh), p=0.8, dtype='float32')
        [target_h_bck, c], u = theano.scan(fn=recurrence,
                                sequences=[target_x_word.dimshuffle(1,0,2)[::-1,:,:], target_idxs.dimshuffle(1,0)[::-1,:]],
                                non_sequences=target_bck_params+[maskd7, maskd8],
                                outputs_info=[T.alloc(self.h0, target_x_word.shape[0],nh), T.alloc(self.h0, target_x_word.shape[0],nh)],
                                n_steps=target_x_word.shape[1],
                                strict=True)


        if self.supervised_gen:
            maskd9 = srng.binomial((source_target_x_word.shape[0],source_target_x_word.shape[-1]), p=0.8, dtype='float32')
            maskd10 = srng.binomial((source_target_x_word.shape[0],nh), p=0.8, dtype='float32')
            [source_target_h_fwd, cm], u = theano.scan(fn=recurrence,
                                    sequences=[source_target_x_word.dimshuffle(1,0,2), source_target_idxs.dimshuffle(1,0)],
                                    non_sequences=target_fwd_params+[maskd5, maskd6],
                                    outputs_info=[T.alloc(self.h0, source_target_x_word.shape[0],nh), T.alloc(self.h0, source_target_x_word.shape[0],nh)],
                                    n_steps=source_target_x_word.shape[1],
                                    strict=True)

            maskd11 = srng.binomial((source_target_x_word.shape[0],source_target_x_word.shape[-1]), p=0.8, dtype='float32')
            maskd12 = srng.binomial((source_target_x_word.shape[0],nh), p=0.8, dtype='float32')
            [source_target_h_bck, c], u = theano.scan(fn=recurrence,
                                    sequences=[source_target_x_word.dimshuffle(1,0,2)[::-1,:,:], source_target_idxs.dimshuffle(1,0)[::-1,:]],
                                    non_sequences=target_bck_params+[maskd11, maskd12],
                                    outputs_info=[T.alloc(self.h0, source_target_x_word.shape[0],nh), T.alloc(self.h0, source_target_x_word.shape[0],nh)],
                                    n_steps=source_target_x_word.shape[1],
                                    strict=True)

            source_target_h_bck = source_target_h_bck[::-1,:,:].dimshuffle(1,0,2)
            source_target_h_fwd = source_target_h_fwd.dimshuffle(1,0,2)
            source_target_h_priv = T.concatenate([source_target_h_fwd, source_target_h_bck], axis=2)
            source_target_h = source_target_h_priv.max(axis=1)

            pyx_source_target = T.nnet.nnet.sigmoid(T.dot(source_target_h, self.w_o) + self.b_o.dimshuffle('x', 0))
            pyx_source_target = T.clip(pyx_source_target, 1e-5, 1-1e-5)

        source_h_bck = source_h_bck[::-1,:,:].dimshuffle(1,0,2)
        source_h_fwd = source_h_fwd.dimshuffle(1,0,2)
        source_h_priv = T.concatenate([source_h_fwd, source_h_bck], axis=2)
        source_h = source_h_priv.max(axis=1)
        source_h = dropout(source_h, dropout_switch, 0.5)

        target_h_bck = target_h_bck[::-1,:,:].dimshuffle(1,0,2)
        target_h_fwd = target_h_fwd.dimshuffle(1,0,2)
        target_h_priv = T.concatenate([target_h_fwd, target_h_bck], axis=2)
        target_h = target_h_priv.max(axis=1)
        target_h = dropout(target_h, dropout_switch, 0.5)
        #target_h = T.log(T.exp(target_h_priv).sum(axis=1))
        #target_h = snelu(T.dot(target_h, self.w_h_o) + self.b_h_o.dimshuffle('x',0))
        target_h_test = target_h
    
        pyx_source = T.nnet.nnet.sigmoid(T.dot(source_h, self.w_o) + self.b_o.dimshuffle('x', 0))
        pyx_source = T.clip(pyx_source, 1e-5, 1-1e-5)

        self.step = theano.shared(np.float32(0))

        source_h2 = rectify(T.dot(source_h, self.w_h_1) + self.b_h_1)
        #source_h2 = dropout(source_h2, dropout_switch, 0.5)
        source_h2 = rectify(T.dot(source_h2, self.w_h_2) + self.b_h_2)
        #source_h2 = dropout(source_h2, dropout_switch, 0.5)

        target_h2 = rectify(T.dot(target_h, self.w_h_1) + self.b_h_1)
        #target_h2 = dropout(target_h2, dropout_switch, 0.5)
        target_h2 = rectify(T.dot(target_h2, self.w_h_2) + self.b_h_2)
        #target_h2 = dropout(target_h2, dropout_switch, 0.5)

        pyx_adv_source = T.nnet.nnet.sigmoid(T.dot(source_h2, self.w_adv) + self.b_adv.dimshuffle('x',0))
        pyx_adv_source = T.clip(pyx_adv_source, 1e-5, 1-1e-5)

        pyx_adv_target = T.nnet.nnet.sigmoid(T.dot(target_h2, self.w_adv) + self.b_adv.dimshuffle('x',0))
        pyx_adv_target = T.clip(pyx_adv_target, 1e-5, 1-1e-5)

        #tgt_attention = T.nnet.nnet.sigmoid(T.dot(target_h_test, self.attention_w) + self.attention_b.dimshuffle('x', 0))
        #pyx_test= tgt_attention*T.nnet.nnet.sigmoid(T.dot(target_h_test, self.w_o) + self.b_o.dimshuffle('x', 0)) + (1.-tgt_attention)*T.nnet.nnet.sigmoid(T.dot(target_h_test, self.w_o2) + self.b_o2.dimshuffle('x', 0))
        pyx_test= T.nnet.nnet.sigmoid(T.dot(target_h_test, self.w_o) + self.b_o.dimshuffle('x', 0))

        if self.supervised_gen:
            L_source_target = T.nnet.binary_crossentropy(pyx_source_target.flatten(), source_Y).mean()
            L_adv_generator = -T.log(pyx_adv_target).mean() + L_source_target
            updates_generator, _ = Adam(L_adv_generator, self.params_target, lr2=0.0001)
            self.train_batch_generator = theano.function([target_idxs, target_e1_pos_idxs, target_e2_pos_idxs,
                source_target_e1_pos_idxs, source_target_e2_pos_idxs, source_target_idxs,\
                source_Y, dropout_switch],
                L_adv_generator, updates=updates_generator, allow_input_downcast=True, on_unused_input='ignore')
        else:
            if use_feature_matching:
                L_adv_generator = ((target_h2.mean(axis=0) - source_h2.mean(axis=0))**2).sum()
                updates_generator, _ = Adam(L_adv_generator, self.params_target, lr2=0.0001)
                self.train_batch_generator = theano.function([target_idxs, target_e1_pos_idxs, target_e2_pos_idxs,\
                    source_idxs, source_e1_pos_idxs, source_e2_pos_idxs,\
                    dropout_switch],
                    L_adv_generator, updates=updates_generator, allow_input_downcast=True, on_unused_input='ignore')
            else:
                L_adv_generator = -T.log(pyx_adv_target).mean()
                #L_adv_generator = -.9*T.log(pyx_adv_target).mean() - .1*T.log(1.-pyx_adv_target).mean()
                '''
                if True:
                    L_adv_generator += .5*((self.avg_emb - self.target_emb)**2).sum()
                if True:
                    L_adv_generator += .5*((self.avg_pos - self.target_pos)**2).sum()
                if True:
                    L_adv_generator += .5*sum([((t - s)**2).sum() for s,t in zip(self.params_avg, self.params_target[2:])])
                '''

                updates_generator, _ = Adam(L_adv_generator, self.params_target[1:], lr2=0.0001)
                '''
                updates_generator.append((self.avg_emb, 0.99*self.avg_emb + 0.01*self.target_emb))
                updates_generator.append((self.avg_pos, 0.99*self.avg_pos + 0.01*self.target_pos))
                for p, t in zip(self.params_avg, self.params_target[2:]):
                    updates_generator.append((p, 0.99*p + 0.01*t))
                '''
                self.train_batch_generator = theano.function([target_idxs, target_e1_pos_idxs, target_e2_pos_idxs,\
                    dropout_switch],
                    L_adv_generator, updates=updates_generator, allow_input_downcast=True, on_unused_input='ignore')

        #L_adv_discriminator = -((1.-srng2.uniform(low=0.0, high=0.3, size=pyx_adv_target.shape))*T.log(1-pyx_adv_target)).mean() - T.log(pyx_adv_source).mean()
        #L_adv_discriminator = -T.log(1-pyx_adv_target).mean() - ((srng2.uniform(low=0.7, high=1.2, size=pyx_adv_target.shape))*T.log(pyx_adv_source)).mean()
        #L_adv_discriminator = -0.9*T.log(1.-pyx_adv_target).mean() - .9*T.log(pyx_adv_source).mean() - .1*T.log(pyx_adv_target).mean() - .1*T.log(1.-pyx_adv_source).mean()
        #L_adv_discriminator = -T.log(1.-pyx_adv_target).mean() - .9*T.log(pyx_adv_source).mean() - .1*T.log(1.-pyx_adv_source).mean()
        L_adv_discriminator = -T.log(1.-pyx_adv_target).mean() - T.log(pyx_adv_source).mean()
        #L_adv_discriminator = -T.log(1.-pyx_adv_target).mean() - (srng2.uniform(low=0.7, high=1.2, size=pyx_adv_target.shape)*T.log(pyx_adv_source)).mean()
        updates_discriminator, self.disc_lr = Adam(L_adv_discriminator, self.params_discriminator, lr2=0.0001)

        #L_source = T.nnet.binary_crossentropy(pyx_source.flatten(), source_Y).mean() + 1e-5*sum([(x**2).sum() for x in self.params_source])
        L_source = T.nnet.binary_crossentropy(pyx_source.flatten(), source_Y).mean()
        updates_source, _ = Adam(L_source, self.params_source, lr2=0.001)

        self.train_batch_source = theano.function([source_idxs, source_e1_pos_idxs, source_e2_pos_idxs, source_Y,\
            dropout_switch],
             L_source, updates=updates_source, allow_input_downcast=True, on_unused_input='ignore')

        self.train_batch_discriminator = theano.function([target_idxs, source_idxs, target_e1_pos_idxs, target_e2_pos_idxs,\
            source_e1_pos_idxs, source_e2_pos_idxs, dropout_switch],
            L_adv_discriminator, updates=updates_discriminator, allow_input_downcast=True, on_unused_input='ignore')

        self.predict_proba = theano.function([target_idxs, target_e1_pos_idxs, target_e2_pos_idxs, dropout_switch],\
                pyx_test.flatten(), allow_input_downcast=True, on_unused_input='ignore')
        self.predict_src_proba = theano.function([source_idxs, source_e1_pos_idxs, source_e2_pos_idxs, dropout_switch],\
                pyx_source.flatten(), allow_input_downcast=True, on_unused_input='ignore')

    def __getstate__(self):
        values = [x.get_value() for x in self.params_source]
        return values

    def __setstate__(self, weights):
        for x,w in zip(self.params_source, weights):
            x.set_value(w) 

    def __settarget__(self):
        if self.supervised_gen:
            for ps, pt in zip(self.params_source[2:], self.params_target):
                pt.set_value(ps.get_value())
        else:
            for ps, pt in zip(self.params_source[2:], self.params_target):
                pt.set_value(ps.get_value())
            for ps, pt in zip(self.params_source[4:], self.params_avg):
                pt.set_value(ps.get_value())
            self.avg_emb.set_value(self.emb.get_value())
            self.avg_pos.set_value(self.pos.get_value())
            #self.params_target[0].set_value(self.params_source[2].get_value())
        return
    def __resetdiscriminator__(self):
        self.w_h_1.set_value(he_normal((self.nh*2, 2048)).astype('float32'))
        self.b_h_1.set_value(np.zeros((2048,)).astype('float32'))
        self.w_h_2.set_value(he_normal((2048,2048)).astype('float32'))
        self.b_h_2.set_value(np.zeros((2048,)).astype('float32'))
        self.w_h_3.set_value(he_normal((2048,2048)).astype('float32'))
        self.b_h_3.set_value(np.zeros((2048,)).astype('float32'))
        self.w_adv.set_value(he_normal((2048,1)).astype('float32'))
        self.b_adv.set_value(np.zeros((1,)).astype('float32'))
        return

def bilstm_weights(de, nh):
    # Level 1 Bi-LSTM Weights
    Wf_i = theano.shared(name='w_i',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Uf_i = theano.shared(name='u_i',
                            value=he_normal((nh, nh))
                           .astype("float32"))
    bf_i = theano.shared(name='b_i',
                            value=np.zeros((nh), dtype="float32"))

    Wf_f = theano.shared(name='w_f',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Uf_f = theano.shared(name='u_f',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    bf_f = theano.shared(name='b_f',
                            value=np.ones((nh), dtype="float32"))

    Wf_c = theano.shared(name='w_c',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Uf_c = theano.shared(name='u_c',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    bf_c = theano.shared(name='b_c',
                            value=np.zeros((nh), dtype="float32"))

    Wf_o2 = theano.shared(name='woo',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Uf_o = theano.shared(name='uoo',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    bf_o2 = theano.shared(name='boo',
                            value=np.zeros((nh), dtype="float32"))
    #LSTM 2
    Wb_i = theano.shared(name='wb_i',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Ub_i = theano.shared(name='ub_i',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    bb_i = theano.shared(name='bb_i',
                            value=np.zeros((nh), dtype="float32"))

    Wb_f = theano.shared(name='wb_f',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Ub_f = theano.shared(name='ub_f',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    #ones
    bb_f = theano.shared(name='bb_f',
                            value=np.ones((nh), dtype="float32"))

    Wb_c = theano.shared(name='wb_c',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Ub_c = theano.shared(name='ub_c',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    bb_c = theano.shared(name='bb_c',
                            value=np.zeros((nh), dtype="float32"))

    Wb_o2 = theano.shared(name='wboo',
                            value=he_normal((de, nh))
                           .astype("float32"))
    Ub_o = theano.shared(name='uboo',
                            value=orthogonal_tmp((nh, nh))
                           .astype("float32"))
    bb_o2 = theano.shared(name='bboo',
                            value=np.zeros((nh), dtype="float32"))

    params_forward =  [Wb_i, Ub_i, bb_i,
                   Wb_c, Ub_c, bb_c,
                   Wb_f, Ub_f, bb_f,
                   Wb_o2, Ub_o, bb_o2]

    params_backward =  [Wf_i, Uf_i, bf_i,
                   Wf_c, Uf_c, bf_c,
                   Wf_f, Uf_f, bf_f,
                   Wf_o2, Uf_o, bf_o2]

    return params_forward, params_backward
